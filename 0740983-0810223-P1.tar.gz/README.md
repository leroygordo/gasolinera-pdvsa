 - Entrada de argumentos, incluso en cualquier orden, sin validacion de rango.
 - Lectura del archivo ficheros.
 - Comunicacion cliente-servidor con hilos.
 - Control del inventario con un hilo, en bomba.

Integrantes: Susana Charara   08-10223
             Hancel Gonzalez  07-40983
